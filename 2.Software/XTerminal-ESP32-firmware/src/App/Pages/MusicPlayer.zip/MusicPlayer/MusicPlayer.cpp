#include "MusicPlayer.h"
#include "App/App.h"
#include "App/Configs/Version.h"
#include "HAL/HAL.h"

using namespace Page;
#include "map"
std::map<int, std::string> map_file_list;
extern uint8_t enc_long_push_flag;



#ifdef ARDUINO
#include "HAL/HAL_Audio.h"
#include "Audio.h"
Audio* audio;
#else
fs::FS SD;

static const char *title_list[] = {
	"Waiting for true love",
	"Need a Better Future",
	"Vibrations",
	"Why now?",
	"Never Look Back",
	"It happened Yesterday",
	"Feeling so High",
	"Go Deeper",
	"Find You There",
	"Until the End",
	"Unknown",
	"Unknown",
	"Unknown",
	"Unknown",
};
#endif


void audio_init()
{
#ifdef USE_I2S

	audio = new Audio();

	if (audio != nullptr)
	{
		audio->setPinout(CONFIG_I2S_BCLK, CONFIG_I2S_LRC, CONFIG_I2S_DOUT);
		audio->setVolume(8); // 0...21
}
    
#endif
    
}

void audio_start()
{
#ifdef USE_I2S
if(audio!=nullptr)
{
    audio->connecttoFS(SD, "/1.mp3");
	
}
#endif
}

void audio_play(const char* name)
{
#ifdef USE_I2S
if(audio!=nullptr)
{
    audio->connecttoFS(SD, name);
	
}
#endif
}

void audio_loop()
{
#ifdef USE_I2S
if(audio!=nullptr)
{
    audio->loop();
	
}
#endif
}
void audio_delete()
{
#ifdef USE_I2S
	if (audio != nullptr)
	{
		delete audio;


	}
#endif
}

void MusicPlayer::fileListClickCB(lv_event_t *event)
{
	lv_obj_t *obj = lv_event_get_target(event);
	lv_event_code_t code = lv_event_get_code(event);
	// int index = *((int*)lv_obj_get_user_data(obj));
	auto *instance = (MusicPlayer *)lv_obj_get_user_data(obj);
	if (code == LV_EVENT_RELEASED)
	{
		instance->Manager->Pop();
		// std::map<int, std::string>::iterator l_it;
		// l_it = map_file_list.find(index);
		// if (l_it != map_file_list.end())
		// {
		// 	const char *name = l_it->second.c_str();
		// 	printf("Listing directory: %s\n", name);
		// 	audio_play(name);
		// }
	}

	if (code == LV_EVENT_LONG_PRESSED)
	{
		 enc_long_push_flag = 1;
	}
}

void MusicPlayer::ListDirFiles(fs::FS &fs, const char *dirname, uint8_t levels)
{
	// fs::FS &fs=SD;
	// const char *dirname = "/";
	// uint8_t levels=0;

#ifdef ARDUINO
	Serial.printf("Listing directory: %s\n", dirname);

	File root = fs.open(dirname);
	if (!root)
	{
		Serial.println("Failed to open directory");
		return;
	}
	if (!root.isDirectory())
	{
		Serial.println("Not a directory");
		return;
	}

	File file = root.openNextFile();
	int file_index = 0;

	while (file)
	{
		if (file.isDirectory())
		{
			// Serial.print("  DIR : ");
			// Serial.println(file.name());
			// if (levels)
			// {
			//     ListDirFiles(fs, file.name(), levels - 1);
			// }
		}
		else
		{
			Serial.print("  FILE: ");
			Serial.print(file.name());
			Serial.print("  SIZE: ");
			Serial.println(file.size());

			lv_obj_t *list_file_btn = lv_list_add_btn(View.ui.file_list, LV_SYMBOL_FILE, file.name());
			lv_group_add_obj(View.ui.group, list_file_btn);
			lv_obj_set_style_text_font(list_file_btn, &lv_font_montserrat_14, 0);
			lv_obj_set_style_text_color(list_file_btn, lv_color_white(), 0);
			lv_obj_set_style_bg_color(list_file_btn, lv_color_black(), 0);

			int index = file_index;
			lv_obj_set_user_data(list_file_btn, (void *)index);
			lv_obj_add_event_cb(list_file_btn, fileListClickCB, LV_EVENT_ALL, &index);
			map_file_list.insert(std::map<int, std::string>::value_type(file_index, file.name()));
			file_index++;
		}
		file = root.openNextFile();
	}

#else
	int file_index = 0;
	for (int i = 0; i < 4; i++)
	{
		lv_obj_t *list_file_btn = lv_list_add_btn(View.ui.file_list, LV_SYMBOL_FILE, title_list[i]);
		lv_group_add_obj(View.ui.group, list_file_btn);
		lv_obj_set_style_text_font(list_file_btn, &lv_font_montserrat_14, 0);
		lv_obj_set_style_text_color(list_file_btn, lv_color_white(), 0);
		lv_obj_set_style_bg_color(list_file_btn, lv_color_black(), 0);

		// int* index = (int*)malloc(sizeof(int));
		// *index = file_index;
		// lv_obj_set_user_data(list_file_btn, (void*)index);
		// lv_obj_add_event_cb(list_file_btn, fileListClickCB, LV_EVENT_ALL, nullptr);

		lv_obj_set_user_data(list_file_btn, this);
		lv_obj_add_event_cb(list_file_btn, fileListClickCB, LV_EVENT_ALL, this);

		map_file_list.insert(std::map<int, std::string>::value_type(file_index, title_list[i]));
		file_index++;
	}

#endif
}

MusicPlayer::MusicPlayer()
{
}

MusicPlayer::~MusicPlayer()
{
}

void MusicPlayer::onCustomAttrConfig()
{
}

void MusicPlayer::onViewLoad()
{
	View.Create(root);
	AttachEvent(root);
}

void MusicPlayer::onViewDidLoad()
{
	ListDirFiles(SD, "/", 0);
}

void MusicPlayer::onViewWillAppear()
{
	audio_init();

	lv_indev_set_group(lv_get_indev(LV_INDEV_TYPE_ENCODER), View.ui.group);
	StatusBar::SetStyle(StatusBar::STYLE_TRANSP);

	timer = lv_timer_create(onTimerUpdate, 100, this);
	lv_timer_ready(timer);

	// View.SetScrollToY(root, -LV_VER_RES, LV_ANIM_OFF);
	lv_obj_fade_in(root, 300, 0);
}

void MusicPlayer::onViewDidAppear()
{
	// View.onFocus(View.ui.group);
}

void MusicPlayer::onViewWillDisappear()
{
	lv_obj_fade_out(root, 300, 0);

	// audio.stopSong();
	// audio_delete();
}

void MusicPlayer::onViewDidDisappear()
{
	lv_timer_del(timer);
}

void MusicPlayer::onViewDidUnload()
{
	// View.Delete();
}

void MusicPlayer::AttachEvent(lv_obj_t *obj)
{
	lv_obj_set_user_data(obj, this);
	lv_obj_add_event_cb(obj, onEvent, LV_EVENT_ALL, this);
}

void MusicPlayer::Update()
{
	if(enc_long_push_flag==1)
	{
        enc_long_push_flag = 0;
		Manager->Pop();
	}
}

void MusicPlayer::onTimerUpdate(lv_timer_t *timer)
{
	MusicPlayer *instance = (MusicPlayer *)timer->user_data;

	instance->Update();
}

void MusicPlayer::onEvent(lv_event_t *event)
{
	lv_obj_t *obj = lv_event_get_target(event);
	lv_event_code_t code = lv_event_get_code(event);
	auto *instance = (MusicPlayer *)lv_obj_get_user_data(obj);
	if (code == LV_EVENT_RELEASED)
	{
	}
}
