// #ifndef __MusicPlayer_PRESENTER_H
// #define __MusicPlayer_PRESENTER_H
#pragma once

#include "MusicPlayerView.h"

#ifdef ARDUINO
#include "HAL/HAL_SdCard.h"
#else
namespace fs
{
    class FS
    {
    public:

    };
};

#endif


namespace Page
{

class MusicPlayer : public PageBase
{
public:

public:
    MusicPlayer();
    virtual ~MusicPlayer();

    virtual void onCustomAttrConfig();
    virtual void onViewLoad();
    virtual void onViewDidLoad();
    virtual void onViewWillAppear();
    virtual void onViewDidAppear();
    virtual void onViewWillDisappear();
    virtual void onViewDidDisappear();
    virtual void onViewDidUnload();

private:
    void Update();
    void AttachEvent(lv_obj_t* obj);
    static void onTimerUpdate(lv_timer_t* timer);
    static void onEvent(lv_event_t* event);

private:
    MusicPlayerView View;
    lv_timer_t* timer;
    void ListDirFiles(fs::FS &fs, const char *dirname, uint8_t levels);
    static void fileListClickCB(lv_event_t *event);
};
}

// #endif
